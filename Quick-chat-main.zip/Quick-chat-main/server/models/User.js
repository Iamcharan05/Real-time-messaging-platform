import mongoose from "mongoose";

const userSchema = new mongoose.Schema({
    email: {
        type: String,
        required: true,
        unique: true
    },
    fullName: {
        type: String,
        required: true,
    },
    password: {
        type: String,
        required: true,
    },
    profilePic: {
        type: String,
        default: ""
    },
    bio: {
        type: String,
    },
    friends: [{
        type: mongoose.Schema.Types.ObjectId,
        ref: "User"
    }],
    incomingRequests: [{
        type: mongoose.Schema.Types.ObjectId,
        ref: "User"
    }],
     publicKey: {
        type: String,
        required: true
    },

    encryptedPrivateKey: {
        type: String,
        required: true
    },
     salt: {
        type: String,
        required: true
    },

    iv: {
        type: String,
        required: true
    },
    outgoingRequests: [{
        type: mongoose.Schema.Types.ObjectId,
        ref: "User"
    }]
}, { timestamps: true })

const User = mongoose.model("User", userSchema)

export default User;